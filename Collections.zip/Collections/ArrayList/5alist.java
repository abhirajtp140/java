import java.util.*;

public class collections {
	public static void main(String[] args) {
		List<String> clr= new ArrayList<>();
		clr.add("Green");
		clr.add("Yellow");
		clr.add("Red");
		clr.set(clr.indexOf("Yellow"),"Blue");
		System.out.println(clr.toString());
	}
}
