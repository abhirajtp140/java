import java.util.*;
import java.util.ArrayList;
public class collections {
	public static void main(String[] args) {
		List<String> clr= new ArrayList<>();
		clr.add("Green");
		clr.add("Yellow");
		clr.add("Red");
		clr.set(1, "Blue");
		System.out.println(clr.toString());
	}
}