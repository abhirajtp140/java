import java.util.*;

public class collections {
	public static void main(String[] args) {
		List<String> clr= new ArrayList<>();
		clr.add("Green");
		clr.add("Yellow");
		clr.add("Red");
		Collections.sort(clr,Collections.reverseOrder());
		System.out.println(clr.toString());
	}
}