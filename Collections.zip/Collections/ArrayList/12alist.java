import java.util.*;

public class collections {
	public static void main(String[] args) {
		List<String> clr= new ArrayList<>();
		clr.add("Green");
		clr.add("Yellow");
		clr.add("Red");
		System.out.println(clr.subList(0, 2));
	}
}
