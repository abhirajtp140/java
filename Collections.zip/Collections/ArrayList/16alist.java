import java.util.*;

public class collections {
	public static void main(String[] args) {
		List<String> clr= new ArrayList<>();
		List<String> rang= new ArrayList<>();
		clr.add("Green");
		clr.add("Yellow");
		clr.add("Red");
		rang=clr;
		System.out.println(rang.toString());
	}
}