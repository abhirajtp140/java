import java.util.*;

public class collections {
	public static void main(String[] args) {
		List<String> clr= new ArrayList<>();
		clr.add("Green");
		clr.add("Yellow");
		clr.add("Red");
		List<String> cl= new ArrayList<>();
		cl.add("Blue");
		cl.add("Grey");
		cl.add("violet");
		Iterator<String> itr =cl.listIterator();
		while(itr.hasNext())
		{
			clr.add(itr.next());
		}
		System.out.print(clr.toString());
	}
}