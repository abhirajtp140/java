import java.util.*;

public class collections {
	public static void main(String[] args) {
		List<String> clr= new ArrayList<>();
		clr.add("Green");
		clr.add("Yellow");
		clr.add("Red");
		clr.set(0, clr.set(1,clr.get(0)));
		System.out.print(clr.toString());
	}
}