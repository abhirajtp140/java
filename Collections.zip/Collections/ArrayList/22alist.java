import java.util.*;
import java.util.ArrayList;
public class collections {
	public static void main(String[] args) {
		List<String> clr= new ArrayList<>();
		clr.add("Green");
		clr.add("Yellow");
		clr.add("Red");
		for(int i=0;i<clr.size();i++)
		System.out.println(clr.get(i));
	}
}