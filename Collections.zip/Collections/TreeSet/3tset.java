import java.util.*;

public class collections {
	public static void main(String[] args) {
		Set<String> clr= new TreeSet<>();
		clr.add("Green");
		clr.add("Yellow");
		clr.add("Red");
		clr.add("Black");
		Set<String> cl= new TreeSet<>();
		cl.add("Blue");
		cl.add("White");
		cl.add("Gray");
		cl.add("Violet");
		Iterator<String> itr=cl.iterator();
		while(itr.hasNext())
		clr.add(itr.next());
		System.out.print(clr.toString());
	}
}