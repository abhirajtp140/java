import java.util.*;

public class collections {
	public static void main(String[] args) {
		Set<String> clr= new TreeSet<>();
		clr.add("Green");
		clr.add("Yellow");
		clr.add("Red");
		clr.add("Black");
		Set<String> cl= new TreeSet<>();
		cl.add("Green");
		cl.add("Yellow");
		cl.add("Red");
		cl.add("Black");
		Iterator itr=clr.iterator();
		System.out.println(clr.equals(cl));
	}
}