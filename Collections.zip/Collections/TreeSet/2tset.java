import java.util.*;

public class collections {
	public static void main(String[] args) {
		Set<String> clr= new TreeSet<>();
		clr.add("Green");
		clr.add("Yellow");
		clr.add("Red");
		clr.add("Black");
		Iterator<String> itr=clr.iterator();
		while(itr.hasNext())
		System.out.println(itr.next());
	}
}