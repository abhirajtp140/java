import java.util.*;

public class collections {
	public static void main(String[] args) {
		Set<Integer> clr= new TreeSet<>();
		clr.add(2);
		clr.add(8);
		clr.add(10);
		clr.add(4);
		clr.add(5);
		clr.add(9);
		int n=0;
		Iterator itr=clr.iterator();
		if(itr.hasNext()) {
			System.out.println(clr.remove(itr.next()));
		}
		System.out.println(clr.toString());
	}
}