import java.util.*;

public class collections {
	public static void main(String[] args) {
		String str="";
		Set<String> clr= new TreeSet<>();
		clr.add("Green");
		clr.add("Yellow");
		clr.add("Red");
		clr.add("Black");
		Iterator itr=clr.iterator();
		if(itr.hasNext())
		System.out.println(itr.next());
		while(itr.hasNext()) {
			str=(String) itr.next();
		}
		System.out.println(str);
	}
}