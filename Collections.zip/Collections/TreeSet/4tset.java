import java.util.*;

public class collections {
	public static void main(String[] args) {
		Set<String> clr= new TreeSet<>();
		clr.add("Green");
		clr.add("Yellow");
		clr.add("Red");
		clr.add("Black");
		List<String> list=new ArrayList<>(clr);
		Collections.sort(list,Collections.reverseOrder());
		System.out.println(list.toString());
	}
}