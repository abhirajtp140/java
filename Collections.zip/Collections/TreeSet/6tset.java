import java.util.*;

public class collections {
	public static void main(String[] args) {
		Set<String> clr= new TreeSet<>();
		clr.add("Green");
		clr.add("Yellow");
		clr.add("Red");
		clr.add("Black");
		Iterator itr=clr.iterator();
		Set<String> cl=new TreeSet<>(clr);
		System.out.println(cl.toString());
	}
}