import java.sql.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.TimeZone;
public class jdbc
{
public static void main(String[] args)
{
	try {
			int opt,i=0;
			String s="";
			Map<String,String> med=new HashMap<>();
			med.put("1", "54");
			med.put("2", "14");
			med.put("3", "5");
			med.put("4", "7");
			Scanner sc=new Scanner(System.in);
			operations op=new operations();
			Connection myConn=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/test?serverTimezone=" + TimeZone.getDefault().getID(), "root", "");
			Statement myStmt=myConn.createStatement();
			System.out.println("1. Get all details\n2. Insert data\n3. update stock\n4. Search reamining stock\n5. Remove medicine\n6. Sell");
			opt=sc.nextInt();
			switch(opt) {
			case 1:
				s=op.sAll();
				ResultSet myRs=myStmt.executeQuery(s);
				while(myRs.next())
				{
					System.out.println(myRs.getString("id")+" "+myRs.getString("mName")+" "+myRs.getString("Company")+" "+myRs.getString("Expiry")+" "+myRs.getString("Price")+" "+myRs.getString("Quantity")+" "+myRs.getString("rackNo"));
				}
				break;
			case 2:
				String [] a=new String[7];
				while(i<7) {
					a[i]=sc.next();
					i++;
				}
				s=op.insert(a[0],a[1],a[2],a[3],a[4],a[5],a[6]);
				myStmt.executeUpdate(s);
				med.put(a[0], a[5]);
				break;
			case 3:
				System.out.println("Enter the id");
				String id=sc.next();
				System.out.println("Enter the Stock");
				String stock=sc.next();
				s=op.update(id, stock);
				med.replace(id, stock);
				myStmt.executeUpdate(s);
				break;
			case 4:
				System.out.println("Enter the id");
				id=sc.next();
				System.out.println(id+" remaining stock is "+med.get(id));
				break;
			case 5:
				System.out.println("Enter the id to remove the medicine");
				id=sc.next();
				myStmt.executeUpdate("delete from medstore where id='"+id+"'");
				med.remove(id);
				break;
			case 6:
				System.out.println("Enter the id of the medicine");
				id=sc.next();
				System.out.println("Enter the number of stocks needed");
				Integer j=sc.nextInt(),k=Integer.parseInt(med.get(id));
				if(j<=k) {
					k=k-j;
					med.replace(id,""+k);
					myStmt.executeUpdate("update medstore set Quantity='"+k+"' where id='"+id+"'");
				}
			}
			
		}
	catch(Exception exc)
	{
		exc.printStackTrace();
	}
}
}
class operations{
	String sAll() {
		return "select * from medstore";
	}
	String insert(String a1,String a2,String a3,String a4,String a5,String a6,String a7) {
		return "insert into medstore values('"+a1+"','"+a2+"','"+a3+"','"+a4+"','"+a5+"','"+a6+"','"+a7+"')";
	}
	String update(String a,String b) {
		return "update medstore set Quantity='"+b+"' where id='"+a+"'";
	}
}