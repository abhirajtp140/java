import java.util.*;

public class collections {
	public static void main(String[] args) {
		List<String> clr= new LinkedList<>();
		clr.add("Green");
		clr.add("Yellow");
		clr.add("Red");
		Iterator<String> itr=clr.listIterator();
		int size=0;
		while(itr.hasNext())
		System.out.println(itr.next()+" at "+size++);
		
	}
}