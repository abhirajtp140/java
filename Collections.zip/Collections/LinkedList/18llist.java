import java.util.*;

public class collections {
	public static void main(String[] args) {
		List<String> clr= new LinkedList<>();
		clr.add("Green");
		clr.add("Yellow");
		clr.add("Red");
		List<String> cl= new LinkedList<>();
		cl=clr;
		System.out.print(cl.toString());
	}
}