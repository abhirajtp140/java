
public class collections {
	public static void main(String[] args) {
		List<String> clr= new LinkedList<>();
		clr.add("Green");
		clr.add("Yellow");
		clr.add("Red");
		clr.add(1,"Blue");
		System.out.println(clr.toString());
	}
}