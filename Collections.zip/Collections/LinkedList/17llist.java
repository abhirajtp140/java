import java.util.*;

public class collections {
	public static void main(String[] args) {
		List<String> clr= new LinkedList<>();
		clr.add("Green");
		clr.add("Yellow");
		clr.add("Red");
		List<String> cl= new LinkedList<>();
		cl.add("Black");
		cl.add("White");
		cl.add("Blue");
		for(String str:cl)
		clr.add(str);
		System.out.print(clr.toString());
	}
}