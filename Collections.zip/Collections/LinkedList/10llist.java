import java.util.*;

public class collections {
	public static void main(String[] args) {
		  List<String> clr= new LinkedList<>();
		  clr.add("Green");
		  clr.add("Yellow");
		  clr.add("Red");
		  clr.add("Yellow");
		  clr.add("Black");
		  Iterator<String> itr = clr.listIterator();
		  int size=0;
		  while (itr.hasNext()) {
              if(itr.next()=="Yellow"){
            	  System.out.println("First Occurence "+size);
            	  break;
              }
              size++;
	     }
		  itr = clr.listIterator(clr.size());
		  size=clr.size()-1;
		  while (((ListIterator<String>) itr).hasPrevious()) {
              if(((ListIterator<String>) itr).previous()=="Yellow"){
            	  System.out.print("Last Occurence "+size);
                  break;
              }
              size--;
	     }
	}
}