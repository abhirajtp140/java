import java.util.*;

public class collections {
	public static void main(String[] args) {
		List<String> clr= new LinkedList<>();
		clr.add("Green");
		clr.add("Yellow");
		clr.add("Red");
		String b="Blue";
		clr.add(clr.size(),b);
		System.out.println(clr.toString());
	}
}