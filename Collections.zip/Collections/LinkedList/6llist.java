import java.util.*;

public class collections {
	public static void main(String[] args) {
		List<String> clr= new LinkedList<>();
		clr.add("Green");
		clr.add("Yellow");
		clr.add("Red");
		clr.add(0,"Blue");
		clr.add(clr.size(),"Black");
		System.out.println(clr.toString());
	}
}