import java.util.*;

public class collections {
	public static void main(String[] args) {
		Map<Integer,Integer> clr= new HashMap<>();
		clr.put(1, 12);
		clr.put(2, 11);
		clr.put(3, 10);
		clr.put(4, 9);
		Map<Integer,Integer> cl= new HashMap<>();
		cl=clr;
		System.out.println(cl);
	}
}