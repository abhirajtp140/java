import java.util.*;

public class collections {
	public static void main(String[] args) {
		Map<Integer,Integer> clr= new HashMap<>();
		clr.put(1, 12);
		System.out.println(clr);
	}
}