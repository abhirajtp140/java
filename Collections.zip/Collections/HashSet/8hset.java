import java.util.*;

public class collections {
	public static void main(String[] args) {
		Set<String> clr= new HashSet<>();
		clr.add("Green");
		clr.add("Yellow");
		clr.add("Red");
		clr.add("Black");
		Set<String> rang= new TreeSet<>();
		for(String str:clr)
			rang.add(str);
		System.out.println(rang.toString());
	}
}