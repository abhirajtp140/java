import java.util.*;

public class collections {
	public static void main(String[] args) {
		Set<String> clr= new HashSet<>();
		clr.add("Green");
		clr.add("Yellow");
		clr.add("Red");
		clr.add("Black");
		String[] str=new String[clr.size()];
		int i=0;
		for(String st:clr) {
			str[i]=st;
			i++;
		}
		for(String st:str)
		System.out.println(st);
	}
}