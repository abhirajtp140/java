import java.util.*;

public class collections {
	public static void main(String[] args) {
		Set<String> clr= new HashSet<>();
		clr.add("Green");
		clr.add("Yellow");
		clr.add("Red");
		clr.add("Black");
		clr.removeAll(clr);
		System.out.println(clr.toString());
	}
}